import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.harindra.iptvpro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.harindra.iptvpro"
        minSdk = 23 // Media3 1.11.x & LibVLC 3.6.x baseline; Android 6.0+ TV & Mobile devices
        targetSdk = 34
        versionCode = 236
        versionName = "23.6"
        androidResources {
            localeFilters += listOf("en", "hi")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    flavorDimensions += "device"
    productFlavors {
        create("tv") {
            dimension = "device"
            applicationId = "com.harindra.iptvpro"
            versionNameSuffix = "-TV"
            buildConfigField("boolean", "IS_TV_BUILD", "true")
            buildConfigField("String", "DEVICE_FLAVOR", "\"TV\"")
            manifestPlaceholders["appLabel"] = "RAM PLAYER TV"
            manifestPlaceholders["screenOrientation"] = "sensorLandscape"
        }
        create("mobile") {
            dimension = "device"
            applicationId = "com.harindra.iptvpro.mobile"
            versionNameSuffix = "-Mobile"
            buildConfigField("boolean", "IS_TV_BUILD", "false")
            buildConfigField("String", "DEVICE_FLAVOR", "\"MOBILE\"")
            manifestPlaceholders["appLabel"] = "RAM PLAYER Mobile"
            manifestPlaceholders["screenOrientation"] = "sensor"
        }
    }

    signingConfigs {
        val keystorePath = System.getenv("SIGNING_STORE_FILE")
        val keystorePassword = System.getenv("SIGNING_STORE_PASSWORD")
        val keyAlias = System.getenv("SIGNING_KEY_ALIAS")
        val keyPassword = System.getenv("SIGNING_KEY_PASSWORD")

        if (!keystorePath.isNullOrBlank() &&
            !keystorePassword.isNullOrBlank() &&
            !keyAlias.isNullOrBlank() &&
            !keyPassword.isNullOrBlank() &&
            File(keystorePath).isFile
        ) {
            create("release") {
                storeFile = File(keystorePath)
                storePassword = keystorePassword
                this.keyAlias = keyAlias
                this.keyPassword = keyPassword
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    // Ultra-Compact APK Optimization: Per-ABI Splits (drops x86/x86_64 emulators)
    // + compressed native .so packaging -> shrinks 89MB universal APK down to ~18-20MB per APK!
    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = false
        }
    }

    packaging {
        jniLibs {
            // Prevents Android from extracting a duplicate ~58MB uncompressed copy of libvlcjni.so to /data/app
            // (cuts installed TV app storage from ~85-90MB down to ~50-55MB on Android 6.0+!)
            useLegacyPackaging = false
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.kotlin_module",
                "META-INF/*.version",
                "META-INF/proguard/**",
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json"
            )
        }
    }

    buildTypes {
        release {
            // R8 code & resource shrinking enabled, signed so Release APK installs directly on TV
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3Version = "1.11.1"
    val libVlcVersion = "3.6.5"

    // AndroidX Media3 Pro ExoPlayer Core + HLS + DASH + RTSP (Preserved 100% for Live TV)
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-exoplayer-rtsp:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")
    implementation("androidx.media3:media3-datasource-okhttp:$media3Version")

    // RAM PLAYER v22.0 Dedicated VOD Playback Engine: Official VideoLAN LibVLC Android SDK (LGPL 2.1)
    implementation("org.videolan.android:libvlc-all:$libVlcVersion")

    // Coroutines & Networking (Lightweight for 512MB TV)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.github.bumptech.glide:glide:4.16.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
