package com.harindra.iptvpro

import java.util.Locale

/**
 * Clear 7-state playback outcome for every Live TV channel (never leaves broken channels stuck in infinite Connecting/Retrying).
 */
enum class ChannelPlaybackResult(val osdPrefix: String) {
    PLAYING("🟢 Live"),
    CONNECTING("⚡ Connecting"),
    BUFFERING("⏳ Buffering"),
    SWITCHING_ENGINE("⚡ Switching Engine"),
    SERVER_ERROR("⚠️ Server Error"),
    UNSUPPORTED("⚠️ Unsupported Format"),
    UNAVAILABLE("⚠️ Stream Unavailable")
}

enum class ErrorRecoveryAction {
    NONE_STOP,
    RETRY_WITH_COOLDOWN,
    SWITCH_ENGINE_ONCE,
    TRY_BACKUP_URL_ONCE
}

data class StreamErrorDecision(
    val result: ChannelPlaybackResult,
    val action: ErrorRecoveryAction,
    val maxRetries: Int,
    val cooldownMs: Long,
    val userMessage: String,
    val errorFingerprint: String
)

/**
 * RAM PLAYER v23.6 — Per-channel playback session state enforcing strict bounded recovery:
 * - Preserved across primary URL, backup URL, engine fallback, and recovery attempts within one channel play
 * - Never resets backupUrlTried, retryCount, engineSwitchCount, or attemptedUrls during backup/fallback
 * - Tracks attemptedUrls so the exact same URL is never retried in an infinite loop
 * - Enforces hard ceiling of MAX_TOTAL_RECOVERY_ATTEMPTS (3) per playback attempt
 * - Reset ONLY when the user selects a different channel or starts a deliberate fresh playback session
 */
class BoundedRecoverySession(
    val sessionToken: Long,
    val channelKey: String
) {
    companion object {
        const val MAX_TOTAL_RECOVERY_ATTEMPTS = 3
        const val MAX_ENGINE_SWITCHES = 1
    }

    var retryCount: Int = 0
        private set
    var totalRecoveryAttempts: Int = 0
        private set
    var engineSwitchCount: Int = 0
        private set
    var backupUrlTried: Boolean = false
        private set
    var rebufferEvents: Int = 0
        private set

    private val attemptedUrls: LinkedHashSet<String> = LinkedHashSet(4)
    private var lastErrorFingerprint: String = ""
    private var consecutiveSameErrorCount: Int = 0

    fun markUrlAttempted(url: String): Boolean {
        val clean = url.trim()
        if (clean.isEmpty()) return false
        return attemptedUrls.add(clean)
    }

    fun hasAttemptedUrl(url: String): Boolean {
        val clean = url.trim()
        return clean.isNotEmpty() && attemptedUrls.contains(clean)
    }

    fun attemptedUrlCount(): Int = attemptedUrls.size

    fun recordRebuffer(): Int {
        rebufferEvents++
        return rebufferEvents
    }

    fun canSwitchEngine(): Boolean = engineSwitchCount < MAX_ENGINE_SWITCHES && totalRecoveryAttempts < MAX_TOTAL_RECOVERY_ATTEMPTS

    fun markEngineSwitched() {
        engineSwitchCount++
        totalRecoveryAttempts++
    }

    fun markBackupUrlTried(backupUrl: String = "") {
        backupUrlTried = true
        if (backupUrl.isNotBlank()) {
            attemptedUrls.add(backupUrl.trim())
        }
        totalRecoveryAttempts++
    }

    fun evaluateDecision(
        decision: StreamErrorDecision,
        hasBackupUrl: Boolean,
        backupUrlCandidate: String = ""
    ): StreamErrorDecision {
        if (totalRecoveryAttempts >= MAX_TOTAL_RECOVERY_ATTEMPTS && decision.action != ErrorRecoveryAction.NONE_STOP) {
            return decision.copy(
                action = ErrorRecoveryAction.NONE_STOP,
                userMessage = "${decision.userMessage} — Press OK to Retry"
            )
        }

        if (decision.errorFingerprint == lastErrorFingerprint) {
            consecutiveSameErrorCount++
        } else {
            lastErrorFingerprint = decision.errorFingerprint
            consecutiveSameErrorCount = 1
        }

        if (consecutiveSameErrorCount > decision.maxRetries && decision.action == ErrorRecoveryAction.RETRY_WITH_COOLDOWN) {
            return decision.copy(
                action = ErrorRecoveryAction.NONE_STOP,
                userMessage = "${decision.userMessage} — Press OK to Retry"
            )
        }

        val backupAvailableAndUntried = hasBackupUrl && !backupUrlTried &&
            (backupUrlCandidate.isBlank() || !hasAttemptedUrl(backupUrlCandidate))

        return when (decision.action) {
            ErrorRecoveryAction.NONE_STOP -> decision
            ErrorRecoveryAction.SWITCH_ENGINE_ONCE -> {
                if (canSwitchEngine()) {
                    decision
                } else if (backupAvailableAndUntried) {
                    decision.copy(action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE)
                } else {
                    decision.copy(
                        result = ChannelPlaybackResult.UNSUPPORTED,
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "Unsupported stream on this TV"
                    )
                }
            }
            ErrorRecoveryAction.TRY_BACKUP_URL_ONCE -> {
                if (backupAvailableAndUntried) {
                    decision
                } else {
                    decision.copy(
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "${decision.userMessage} — Press OK to Retry"
                    )
                }
            }
            ErrorRecoveryAction.RETRY_WITH_COOLDOWN -> {
                if (retryCount < decision.maxRetries && totalRecoveryAttempts < MAX_TOTAL_RECOVERY_ATTEMPTS) {
                    retryCount++
                    totalRecoveryAttempts++
                    decision
                } else if (backupAvailableAndUntried) {
                    decision.copy(action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE)
                } else {
                    decision.copy(
                        action = ErrorRecoveryAction.NONE_STOP,
                        userMessage = "${decision.userMessage} — Press OK to Retry"
                    )
                }
            }
        }
    }
}

/**
 * RAM PLAYER v23.6 — Smart Channel Intelligence Engine & Unified Cache Policy.
 *
 * Single source of truth for:
 * 1. Pre-playback format/engine selection (remembers winning stage & routes RTMP/AVI/MPG to LibVLC HW).
 * 2. Granular HTTP 401/403/404/429/5xx, DNS, Timeout, Codec & Manifest error classification.
 * 3. Unified, non-overridden LibVLC cache policy aligned with 512MB Android TV memory constraints.
 */
object SmartChannelIntelligenceEngine {

    // Canonical unified LibVLC cache bounds (applied verbatim by LiveTvLibVlcEngine — zero silent override!)
    const val MIN_LIBVLC_CACHE_MS = 1500
    const val LOW_RAM_STARTUP_CACHE_MS = 1500
    const val STANDARD_STARTUP_CACHE_MS = 1800
    const val LOW_RAM_MAX_CACHE_MS = 3300
    const val STANDARD_MAX_CACHE_MS = 4200
    const val REBUFFER_STEP_MS = 600

    fun chooseInitialEngine(
        streamUrl: String,
        globalMode: LiveTvEngineMode,
        rememberedStageOrEngine: String?
    ): LiveTvEngineMode {
        if (globalMode != LiveTvEngineMode.AUTO_OTT_HEAL) {
            return globalMode
        }
        val rem = rememberedStageOrEngine?.trim()?.uppercase(Locale.ROOT).orEmpty()
        when (rem) {
            LiveTvHealStage.VLC_HW_PRIMARY.name,
            LiveTvHealStage.VLC_HW_BACKUP.name,
            LiveTvEngineMode.LIBVLC_HW.id -> return LiveTvEngineMode.LIBVLC_HW
            LiveTvHealStage.VLC_SW_PRIMARY.name,
            LiveTvHealStage.VLC_SW_BACKUP.name,
            LiveTvEngineMode.LIBVLC_SW.id -> return LiveTvEngineMode.LIBVLC_SW
        }

        val lower = streamUrl.trim().lowercase(Locale.ROOT)
        val pathOnly = lower.substringBefore('?')
        if (lower.startsWith("rtmp://") ||
            lower.startsWith("rtmps://") ||
            lower.startsWith("mms://") ||
            lower.startsWith("udp://") ||
            pathOnly.endsWith(".avi") ||
            pathOnly.endsWith(".wmv") ||
            pathOnly.endsWith(".flv") ||
            pathOnly.endsWith(".mpg") ||
            pathOnly.endsWith(".mpeg")
        ) {
            return LiveTvEngineMode.LIBVLC_HW
        }
        return LiveTvEngineMode.AUTO_OTT_HEAL
    }

    fun classifyPlaybackError(
        httpStatusCode: Int,
        errorCodeName: String?,
        message: String?,
        engineMode: LiveTvEngineMode
    ): StreamErrorDecision {
        val codeName = errorCodeName?.trim()?.uppercase(Locale.ROOT).orEmpty()
        val msg = message?.trim()?.lowercase(Locale.ROOT).orEmpty()

        when (httpStatusCode) {
            401, 403 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.NONE_STOP,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = "Auth / Access Denied (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_$httpStatusCode"
            )
            404, 410 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = "Channel Not Found / Expired (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_$httpStatusCode"
            )
            429 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 1,
                cooldownMs = 8000L,
                userMessage = "Server Rate Limited (HTTP 429)",
                errorFingerprint = "HTTP_429"
            )
            in 500..599 -> return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 2,
                cooldownMs = 3500L,
                userMessage = "IPTV Server Busy (HTTP $httpStatusCode)",
                errorFingerprint = "HTTP_5XX"
            )
        }

        val isCodecOrContainer = codeName.contains("DECODING") ||
            codeName.contains("DECODER") ||
            codeName.contains("AUDIO_TRACK") ||
            codeName.contains("PARSING_CONTAINER") ||
            codeName.contains("UNSUPPORTED") ||
            msg.contains("mediacodec") ||
            msg.contains("ac3") ||
            msg.contains("eac3") ||
            msg.contains("dts") ||
            msg.contains("audiotrack") ||
            msg.contains("no suitable decoder")

        if (isCodecOrContainer) {
            val canSwitch = engineMode != LiveTvEngineMode.MEDIA3_ONLY
            return StreamErrorDecision(
                result = if (canSwitch) ChannelPlaybackResult.SWITCHING_ENGINE else ChannelPlaybackResult.UNSUPPORTED,
                action = if (canSwitch) ErrorRecoveryAction.SWITCH_ENGINE_ONCE else ErrorRecoveryAction.NONE_STOP,
                maxRetries = 0,
                cooldownMs = 0L,
                userMessage = if (canSwitch) "Switching to OTT-VLC Engine" else "Unsupported Codec on Device",
                errorFingerprint = "CODEC_$codeName"
            )
        }

        if (codeName.contains("PARSING_MANIFEST") || msg.contains("playlist") || msg.contains("malformed")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.UNAVAILABLE,
                action = ErrorRecoveryAction.TRY_BACKUP_URL_ONCE,
                maxRetries = 1,
                cooldownMs = 1500L,
                userMessage = "Invalid Stream Playlist",
                errorFingerprint = "MANIFEST_INVALID"
            )
        }

        if (msg.contains("unknownhost") || msg.contains("unable to resolve host") || msg.contains("dns")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 1,
                cooldownMs = 4000L,
                userMessage = "DNS / Server Host Unreachable",
                errorFingerprint = "DNS_ERROR"
            )
        }

        if (codeName.contains("TIMEOUT") || msg.contains("timeout") || msg.contains("timed out")) {
            return StreamErrorDecision(
                result = ChannelPlaybackResult.SERVER_ERROR,
                action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
                maxRetries = 2,
                cooldownMs = 3000L,
                userMessage = "Connection Timeout",
                errorFingerprint = "NET_TIMEOUT"
            )
        }

        return StreamErrorDecision(
            result = ChannelPlaybackResult.SERVER_ERROR,
            action = ErrorRecoveryAction.RETRY_WITH_COOLDOWN,
            maxRetries = 2,
            cooldownMs = 3000L,
            userMessage = "Stream Connection Error",
            errorFingerprint = "IO_$codeName"
        )
    }

    /**
     * Unified adaptive LibVLC cache policy (never silently overridden by LiveTvLibVlcEngine):
     * - 512MB Low-RAM TV: starts at 1500ms, caps at 3300ms
     * - 2GB+ TV / Mobile: starts at 1800ms, caps at 4200ms
     */
    fun computeAdaptiveLibVlcCacheMs(
        isLowRamDevice: Boolean,
        rebufferEventsInSession: Int,
        isDegradedNetwork: Boolean
    ): Int {
        val base = if (isLowRamDevice) LOW_RAM_STARTUP_CACHE_MS else STANDARD_STARTUP_CACHE_MS
        val step = (rebufferEventsInSession.coerceAtLeast(0).coerceAtMost(3)) * REBUFFER_STEP_MS
        val netExtra = if (isDegradedNetwork) REBUFFER_STEP_MS else 0
        val maxCap = if (isLowRamDevice) LOW_RAM_MAX_CACHE_MS else STANDARD_MAX_CACHE_MS
        return (base + step + netExtra).coerceIn(MIN_LIBVLC_CACHE_MS, maxCap)
    }
}
