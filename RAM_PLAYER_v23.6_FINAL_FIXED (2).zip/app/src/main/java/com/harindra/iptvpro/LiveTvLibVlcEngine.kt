package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * RAM PLAYER v23.4 — Zero-ANR, Zero-Hang, Anti-Buffer OTT Navigator-Grade LibVLC 3.6.5 Live TV Engine.
 *
 * Key stability guarantees for 512MB Android TVs & Mobile:
 * - All blocking LibVLC JNI calls run on dedicated background thread (`vlcExecutor`) -> 0ms Main Thread block.
 * - Throttled buffering events (max 2 updates/sec) -> prevents UI thread redraw storm & TV hang.
 * - Detects active playback via both `Event.Vout` and `Event.TimeChanged > 500ms` so playing streams
 *   are NEVER falsely killed by the black-screen watchdog.
 * - 3500ms anti-buffer cushion (`--network-caching=3500`, `--live-caching=3500`) -> zero stutter on IPTV.
 */
class LiveTvLibVlcEngine(
    private val context: Context
) {

    interface Callbacks {
        fun onOpening()
        fun onBuffering(percent: Float)
        fun onPlaying()
        fun onFirstVideoFrame(width: Int, height: Int)
        fun onTracksUpdated(audioSummary: String)
        fun onError(reason: String)
        fun onEnded()
    }

    data class VlcAudioTrackInfo(
        val id: Int,
        val name: String,
        val isSelected: Boolean
    )

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val vlcExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "RamPlayer-LiveVLC").apply { isDaemon = true }
    }
    private val generation = AtomicInteger(0)

    @Volatile private var libVlc: LibVLC? = null
    @Volatile private var mediaPlayer: MediaPlayer? = null
    @Volatile private var attachedLayout: VLCVideoLayout? = null
    @Volatile private var callbacks: Callbacks? = null

    @Volatile private var activeForceSoftware: Boolean = false
    @Volatile private var activeCachingMs: Int = SmartChannelIntelligenceEngine.LOW_RAM_STARTUP_CACHE_MS
    @Volatile private var activeUserAgent: String = ""
    @Volatile private var currentUrl: String = ""
    @Volatile private var reportedFirstFrame: Boolean = false
    @Volatile private var currentVolumePct: Int = 100
    @Volatile private var currentAudioDelayMs: Long = 0L
    @Volatile private var lastBufferingUiPostMs: Long = 0L

    fun setCallbacks(callbacks: Callbacks?) {
        this.callbacks = callbacks
    }

    fun attachVideoLayout(layout: VLCVideoLayout) {
        attachedLayout = layout
        val mp = mediaPlayer ?: return
        mainHandler.post {
            runCatching { mp.detachViews() }
            runCatching { mp.attachViews(layout, null, false, false) }
        }
    }

    fun detachVideoLayout() {
        val mp = mediaPlayer
        attachedLayout = null
        if (mp != null) {
            mainHandler.post { runCatching { mp.detachViews() } }
        }
    }

    fun playLiveStream(
        streamUrl: String,
        forceSoftware: Boolean,
        headers: Map<String, String> = emptyMap(),
        networkCachingMs: Int = SmartChannelIntelligenceEngine.LOW_RAM_STARTUP_CACHE_MS
    ): Boolean {
        val cleanUrl = streamUrl.trim()
        if (cleanUrl.isEmpty()) return false

        val ua = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
            ?.takeIf { it.isNotBlank() }
            ?: if (forceSoftware) "VLC/3.0.21 LibVLC/3.0.21" else NetworkClient.resolveEffectiveUserAgent(null)
        val refHeader = headers.entries.firstOrNull { it.key.equals("Referer", ignoreCase = true) }?.value
        val clampedCache = networkCachingMs.coerceIn(SmartChannelIntelligenceEngine.MIN_LIBVLC_CACHE_MS, SmartChannelIntelligenceEngine.STANDARD_MAX_CACHE_MS)

        val gen = generation.incrementAndGet()
        currentUrl = cleanUrl
        reportedFirstFrame = false
        lastBufferingUiPostMs = 0L

        vlcExecutor.execute {
            if (generation.get() != gen) return@execute
            try {
                val needRebuild = libVlc == null ||
                    mediaPlayer == null ||
                    activeForceSoftware != forceSoftware ||
                    activeCachingMs != clampedCache ||
                    activeUserAgent != ua

                if (needRebuild) {
                    val oldMp = mediaPlayer
                    val oldVlc = libVlc
                    mediaPlayer = null
                    libVlc = null
                    if (oldMp != null) {
                        runCatching { oldMp.setEventListener(null) }
                        runCatching { oldMp.stop() }
                        mainHandler.post { runCatching { oldMp.detachViews() } }
                        runCatching { oldMp.release() }
                    }
                    runCatching { oldVlc?.release() }

                    if (generation.get() != gen) return@execute

                    activeForceSoftware = forceSoftware
                    activeCachingMs = clampedCache
                    activeUserAgent = ua

                    val options = ArrayList<String>().apply {
                        add("--network-caching=$clampedCache")
                        add("--live-caching=$clampedCache")
                        add("--file-caching=2500")
                        add("--avcodec-threads=0")
                        add("--clock-jitter=0")
                        add("--clock-synchro=0")
                        add("--drop-late-frames")
                        add("--skip-frames")
                        add("--http-reconnect")
                        if (ua.isNotBlank()) {
                            add("--http-user-agent=$ua")
                        }
                        add("--aout=android_audiotrack")
                        add("--avcodec-fast")
                        add("--deinterlace=-1")
                        add("--deinterlace-mode=yadif")
                        add("--no-stats")
                        if (forceSoftware) {
                            add("--codec=avcodec,all")
                            add("--avcodec-hw=none")
                        }
                    }

                    val newVlc = LibVLC(appContext, options)
                    val newMp = MediaPlayer(newVlc)
                    newMp.setEventListener(eventListener)
                    libVlc = newVlc
                    mediaPlayer = newMp

                    val layout = attachedLayout
                    if (layout != null) {
                        mainHandler.post {
                            if (generation.get() == gen && mediaPlayer === newMp) {
                                runCatching { newMp.detachViews() }
                                runCatching { newMp.attachViews(layout, null, false, false) }
                            }
                        }
                    }
                } else {
                    runCatching { mediaPlayer?.stop() }
                }

                if (generation.get() != gen) return@execute
                val vlc = libVlc ?: return@execute
                val mp = mediaPlayer ?: return@execute

                val media = Media(vlc, Uri.parse(cleanUrl))
                if (forceSoftware) {
                    media.setHWDecoderEnabled(false, false)
                    media.addOption(":no-hw-dec")
                } else {
                    media.setHWDecoderEnabled(true, false)
                }
                media.addOption(":codec=all")
                media.addOption(":network-caching=$clampedCache")
                media.addOption(":live-caching=$clampedCache")
                media.addOption(":http-reconnect")
                if (ua.isNotBlank()) {
                    media.addOption(":http-user-agent=$ua")
                }
                if (!refHeader.isNullOrBlank()) {
                    media.addOption(":http-referrer=$refHeader")
                }

                mp.setMedia(media)
                media.release()
                if (generation.get() != gen) return@execute

                runCatching { mp.setVolume(currentVolumePct) }
                mp.play()
                if (currentAudioDelayMs != 0L) {
                    runCatching { mp.setAudioDelay(currentAudioDelayMs * 1000L) }
                }
            } catch (t: Throwable) {
                if (generation.get() == gen) {
                    mainHandler.post { callbacks?.onError("LibVLC init/play error: ${t.message ?: "unknown"}") }
                }
            }
        }
        return true
    }

    fun isPlaying(): Boolean = runCatching { mediaPlayer?.isPlaying == true }.getOrDefault(false)

    fun isActive(): Boolean = currentUrl.isNotEmpty() && mediaPlayer != null

    fun isSoftwareMode(): Boolean = activeForceSoftware

    fun pause() {
        val mp = mediaPlayer ?: return
        vlcExecutor.execute { runCatching { mp.pause() } }
    }

    fun resume() {
        val mp = mediaPlayer ?: return
        vlcExecutor.execute { runCatching { mp.play() } }
    }

    fun stop() {
        generation.incrementAndGet()
        currentUrl = ""
        reportedFirstFrame = false
        val mp = mediaPlayer ?: return
        vlcExecutor.execute { runCatching { mp.stop() } }
    }

    fun setAudioDelayMs(delayMs: Long) {
        currentAudioDelayMs = delayMs.coerceIn(-2000L, 2000L)
        val mp = mediaPlayer ?: return
        val delayUs = currentAudioDelayMs * 1000L
        vlcExecutor.execute { runCatching { mp.setAudioDelay(delayUs) } }
    }

    fun setVolumePercent(percent: Int) {
        currentVolumePct = percent.coerceIn(0, 150)
        val mp = mediaPlayer ?: return
        val vol = currentVolumePct
        vlcExecutor.execute { runCatching { mp.setVolume(vol) } }
    }

    fun setAspectRatioByResizeIndex(resizeIndex: Int) {
        val mp = mediaPlayer ?: return
        val scaleType = when (resizeIndex % 5) {
            0 -> MediaPlayer.ScaleType.SURFACE_BEST_FIT
            1 -> MediaPlayer.ScaleType.SURFACE_FILL
            2 -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN
            3 -> MediaPlayer.ScaleType.SURFACE_16_9
            else -> MediaPlayer.ScaleType.SURFACE_4_3
        }
        vlcExecutor.execute { runCatching { mp.setVideoScale(scaleType) } }
    }

    fun getAudioTracks(): List<VlcAudioTrackInfo> {
        val mp = mediaPlayer ?: return emptyList()
        val currentId = runCatching { mp.getAudioTrack() }.getOrDefault(-1)
        val raw = runCatching { mp.getAudioTracks() }.getOrNull() ?: return emptyList()
        return raw.mapNotNull { td ->
            if (td == null || td.id < 0) null
            else VlcAudioTrackInfo(
                id = td.id,
                name = td.name.orEmpty().ifBlank { "Audio Track #${td.id}" },
                isSelected = td.id == currentId
            )
        }
    }

    fun selectAudioTrack(trackId: Int): Boolean {
        val mp = mediaPlayer ?: return false
        vlcExecutor.execute { runCatching { mp.setAudioTrack(trackId) } }
        return true
    }

    private fun buildAudioSummary(): String {
        val tracks = getAudioTracks()
        val selected = tracks.firstOrNull { it.isSelected } ?: tracks.firstOrNull()
        return selected?.name?.take(18) ?: "FFmpeg Audio"
    }

    private val eventListener = MediaPlayer.EventListener { event ->
        val snapGen = generation.get()
        when (event.type) {
            MediaPlayer.Event.Opening -> {
                mainHandler.post { if (generation.get() == snapGen) callbacks?.onOpening() }
            }
            MediaPlayer.Event.Buffering -> {
                // Throttle buffering UI callbacks to max 1 per 500ms so 512MB TV UI thread NEVER hangs!
                val now = System.currentTimeMillis()
                val pct = event.buffering
                if (pct >= 99f || (now - lastBufferingUiPostMs) >= 500L) {
                    lastBufferingUiPostMs = now
                    mainHandler.post { if (generation.get() == snapGen) callbacks?.onBuffering(pct) }
                }
            }
            MediaPlayer.Event.Playing -> {
                if (currentAudioDelayMs != 0L) {
                    val delayUs = currentAudioDelayMs * 1000L
                    vlcExecutor.execute { runCatching { mediaPlayer?.setAudioDelay(delayUs) } }
                }
                val summary = buildAudioSummary()
                mainHandler.post {
                    if (generation.get() == snapGen) {
                        callbacks?.onPlaying()
                        callbacks?.onTracksUpdated(summary)
                    }
                }
            }
            MediaPlayer.Event.Vout -> {
                if (event.voutCount > 0 && !reportedFirstFrame) {
                    reportedFirstFrame = true
                    val vt = runCatching { mediaPlayer?.getCurrentVideoTrack() }.getOrNull()
                    val w = vt?.width ?: 0
                    val h = vt?.height ?: 0
                    val summary = buildAudioSummary()
                    mainHandler.post {
                        if (generation.get() == snapGen) {
                            callbacks?.onFirstVideoFrame(w, h)
                            callbacks?.onTracksUpdated(summary)
                        }
                    }
                }
            }
            MediaPlayer.Event.TimeChanged -> {
                // Confirm active playback even if Vout arrived before attachViews, so watchdog NEVER kills a playing stream!
                if (!reportedFirstFrame && event.timeChanged > 500L) {
                    reportedFirstFrame = true
                    val vt = runCatching { mediaPlayer?.getCurrentVideoTrack() }.getOrNull()
                    val w = vt?.width ?: 0
                    val h = vt?.height ?: 0
                    mainHandler.post {
                        if (generation.get() == snapGen) {
                            callbacks?.onFirstVideoFrame(w, h)
                        }
                    }
                }
            }
            MediaPlayer.Event.EndReached -> {
                mainHandler.post { if (generation.get() == snapGen) callbacks?.onEnded() }
            }
            MediaPlayer.Event.EncounteredError -> {
                mainHandler.post { if (generation.get() == snapGen) callbacks?.onError("LibVLC live playback error") }
            }
        }
    }

    fun release() {
        generation.incrementAndGet()
        mainHandler.removeCallbacksAndMessages(null)
        currentUrl = ""
        reportedFirstFrame = false
        attachedLayout = null
        val mp = mediaPlayer
        val vlc = libVlc
        mediaPlayer = null
        libVlc = null
        if (mp != null) {
            runCatching { mp.setEventListener(null) }
            runCatching { mp.detachViews() }
        }
        vlcExecutor.execute {
            runCatching { mp?.stop() }
            runCatching { mp?.release() }
            runCatching { vlc?.release() }
        }
    }
}
